﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraControl : MonoBehaviour
{
    
    CinemachineVirtualCamera cam;
    public CinemachineFramingTransposer composer;
    public Transform playerShadow;
    private Transform cameraTarget;
    Vector3 mouseDownTargetPoint;
    Vector3 mouseDownScreenPoint; 
    Vector2 camShiftTest;
    int cameraState = 0;
    void Start()
    {
        cameraTarget = new GameObject().transform;
        cameraTarget.gameObject.name = "Camera Target";
        playerShadow = GameObject.FindGameObjectWithTag("Player").GetComponent<ShadowInitializer>().myShadow.transform;
        cam = GameObject.FindObjectOfType<CinemachineVirtualCamera>();
        composer = cam.GetCinemachineComponent<CinemachineFramingTransposer>();
        cam.m_Follow = cameraTarget;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.anyKeyDown && !Input.GetMouseButtonDown(0)){
            cameraState = 0;
        }else if(Input.GetMouseButtonDown(0)){
            mouseDownTargetPoint = cameraTarget.position;
            mouseDownScreenPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            cameraState = 1;
        }

        if(Input.GetMouseButton(0)){
            cameraTarget.position = mouseDownTargetPoint + (mouseDownScreenPoint - Camera.main.ScreenToWorldPoint(Input.mousePosition));
        }

        if(Input.GetButtonDown("Camera Shift")){
            if(composer.m_ScreenX == camShiftTest.x && composer.m_ScreenY == camShiftTest.y){
                composer.m_ScreenX = 0.5f;
                composer.m_ScreenY = 0.5f;
            }
            camShiftTest.x = composer.m_ScreenX;
            camShiftTest.y = composer.m_ScreenY;
        }

        if(Input.GetButton("Camera Shift")){
            composer.m_ScreenX = Mathf.Clamp(composer.m_ScreenX-Input.GetAxis("Horizontal")*Time.deltaTime,0.1f,0.9f);
            composer.m_ScreenY = Mathf.Clamp(composer.m_ScreenY-Input.GetAxis("Vertical")*Time.deltaTime,0.1f,0.9f);
        }
        if(cameraState == 0){
            if(playerShadow!= null){
                cameraTarget.position = playerShadow.position;
            }
        }
        
    }
}
