﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CutsceneRunner : MonoBehaviour
{

    [SerializeField]
    public TextAsset cutscene;
    public CharacterData cast;
    public float typingLetterDelay = 0.02f;//in seconds, how long to wait for each letter.
	public Image leftImage;
	public Image rightImage;
	private CanvasGroup canvasGroup;
    bool typing;
    int cutsceneLength;
    bool speakerOnLeft = true;
    string currentTextBoxLine;
    private IEnumerator typeout;//Keep a copy of the executing coroutine so we can stop it.
	struct Line{//data holder for a line of dialogue.
		public string dialogue;
		public Sprite image;
		public string animTrigger;
		public string speakerName;
		public int speakingSide;//0 is auto, switch. 1 is left, 2 is right.
	}
    List<Line> conversation;
    Line lastline;
   	int currentConversationLine;
    public Text dialogueTextUI;
    // Start is called before the first frame update
    void Start(){
        //init cutscene

		canvasGroup = GameObject.FindObjectOfType<CanvasGroup>();
        lastline.dialogue = "<Press Continue>";
		canvasGroup.alpha = 0;
		StartCoroutine(FadeIn());
        //Get references to the sceneboss and told the cutscene to run, and whatever.
    }
    
        
    
    public void InitCutscene(TextAsset s){
		cutscene = s;
		LoadLines();
		currentConversationLine = 0;
		cutsceneLength = conversation.Count;
		PlayDialogue(conversation[currentConversationLine]);
	}
    void FinishTyping(){
		typing = false;
		dialogueTextUI.text = currentTextBoxLine;
		StopCoroutine(typeout);
	}

    void LoadLines(){//Turns the lines of text in the text file to a list of our line structs. 
		string[] lines = cutscene.text.Split('\n');
		conversation = new List<Line>();
		for(int i=0;i<lines.Length;i++){
			string[] linedata = lines[i].Split(':');
			Line templine = new Line();
			templine.speakerName = GetNameFromID(linedata[0]);
			templine.image = GetImageFromID(linedata[0]);
			if(linedata[linedata.Length-2] == "l"){
				templine.speakingSide = 1;
			}else if (linedata[linedata.Length-2] == "r"){
				templine.speakingSide = 2;
			}else{
				templine.speakingSide = 0;//defaukt to switch
			}
			if(linedata[1] == "shake"){
				templine.animTrigger = "shake";
			}else{//if it is anything other than our pre-defined list of animations here, it will go to empty. THat way "l" and "r", which will be read, dont be triggered.
					//also, it means a typo just won't fire the animation, instead of throwing an error. Originally i was going to just pass this through but whitelisting makes sense. Easy enough to do, i have to make every animation by hand anyway.
				templine.animTrigger = null;
			}
			templine.dialogue = linedata[linedata.Length-1];//whatever number of splits, the last will be the dialogue.
			conversation.Add(templine);
		}
	}

    void Update(){
		if (Input.GetButtonDown("Continue")){
			if(typing){
				FinishTyping();
			}else{
				Continue();
			}
		}else if(Input.GetButtonDown("Skip Cutscene")){
            FinishCutscene(false);
        }
	}

	void FinishCutscene(bool fadeOut){
		GameObject.FindObjectOfType<SceneBoss>().CutsceneFinished();
		if(fadeOut){
			StartCoroutine(FadeOutThenUnloadCutScene());
		}else{
			GameObject.FindObjectOfType<SceneBoss>().StartUnloadCutscene();
		}
	}
	IEnumerator FadeOutThenUnloadCutScene(){
		
		float alpha = 1;
		float timeToFade = 0.2f;
		while(Mathf.Clamp(alpha,0,1) > Mathf.Epsilon){
			canvasGroup.alpha = alpha;
			alpha = alpha - Time.deltaTime*1/timeToFade;
			yield return null;
		}
		GameObject.FindObjectOfType<SceneBoss>().StartUnloadCutscene();
		
	}
	IEnumerator FadeIn(){
		float alpha = 0;
		float timeToFade = 0.2f;
		while(Mathf.Clamp(alpha,0,1) < 1){
			canvasGroup.alpha = alpha;
			alpha = alpha + Time.deltaTime*1/timeToFade;
			yield return null;
		}
		canvasGroup.alpha = 1;//Lets not be off by an epsilon or whatever.
	}

    void Continue(){//when we get input from the player.
		currentConversationLine++;
		if (currentConversationLine == cutsceneLength){//the last line of dialogue would have the index cutscenelength - 1, because arrays start at 0. So this is the line after the last line of dialogue.
				PlayDialogue(lastline);//(press to continue) here.
			}else if(currentConversationLine > cutsceneLength){//so this is the line after the line after the last line of dialogue. Which is nothing, lets move on.
				FinishCutscene(true);
			}else{
			PlayDialogue(conversation[currentConversationLine]);
		}
	}
    IEnumerator TypeOut(int startAt, string texttotype){
		string frontload = texttotype.Substring(0,startAt);
		typing = true;
		for(int i = 0;i<texttotype.Length-startAt+1;i++){
			dialogueTextUI.text=frontload+texttotype.Substring(startAt,i);
			yield return new WaitForSeconds(typingLetterDelay);
		}
		typing = false;
	}
    void PlayDialogue(Line line){
		//do an animation "typewriter" thing here.
		if(line.speakerName != null){
			currentTextBoxLine = "<b>"+line.speakerName+":</b>"+line.dialogue;//We don't need a space after the colon because there already is one, if we typed it like that in the dialogue file.
			typeout = TypeOut(line.speakerName.Length+8,currentTextBoxLine);// 1 for ': ' and 7 for '<b></b>' is 9 extra characters to type. could be 9 to not type the space after the :
			StartCoroutine(typeout);//doing this with a reference instead of directly so we can stop it.
		}else{
			typing = false;
			dialogueTextUI.text = line.dialogue;
		}
		//First, if speakingSide is set, lets override and set the speaking side variable.
		if(line.speakingSide == 1){
			speakerOnLeft = true;
		}else if(line.speakingSide == 2){
			speakerOnLeft = false;
		}

		if(speakerOnLeft){
			if(line.image){
				if(line.image != leftImage.sprite){
                    leftImage.GetComponent<ImageSwapHelper>().newsprite = line.image;
					leftImage.GetComponent<Animator>().SetTrigger("swapLeft");
				}
			}
			if(line.animTrigger != null){
				 leftImage.GetComponent<Animator>().SetTrigger(line.animTrigger);
			}
		}else{
			if(line.image){
				if(line.image != rightImage.sprite){
					 rightImage.GetComponent<ImageSwapHelper>().newsprite = line.image;
					 rightImage.GetComponent<Animator>().SetTrigger("swapRight");
				}
			}
			if(line.animTrigger != null){
				 rightImage.GetComponent<Animator>().SetTrigger(line.animTrigger);
			}
		}
		//namebox = line.name;
		speakerOnLeft = !speakerOnLeft;
	}

    ///
    public string GetNameFromID(string testid){
		foreach(CharacterData.Character charstiles in cast.characters){
            if(testid.ToLower() == charstiles.title.ToLower()){
                return charstiles.title;
            }
			foreach(CharacterData.CharacterImage characterImage in charstiles.characterImages){
				if(characterImage.title.ToLower() == testid.ToLower()){
					return charstiles.title;
				}
			}
		}
		return null;
	}
    public Sprite GetImageFromID(string testid){
		foreach(CharacterData.Character charstiles in cast.characters){
            if(testid.ToLower() == charstiles.title.ToLower()){
                return charstiles.defaultImage;
            }
			foreach(CharacterData.CharacterImage characterImage in charstiles.characterImages){
				if(characterImage.title.ToLower() == testid.ToLower()){
					return characterImage.image;
				}
			}
		}
		return null;
	}
}
