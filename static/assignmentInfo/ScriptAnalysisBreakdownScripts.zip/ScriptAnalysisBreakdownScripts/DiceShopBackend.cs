﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiceShopBackend : MonoBehaviour
{
    public IntReference playerGold;
    public IntReference previousGoldGained;
    public DiceReference diceConsideredForPurchase;
    public DiceCollection playerBagOfDice;
    public DiceCollection diceForSale;
    public DiceCollection starterDiceForSale;

    public GameEvent UpdateShopDiceVisuals;
    

    void Start(){
        InitializeForNewGame();
        ResetPreviousGoldGained();
    }

    public void InitializeForNewGame(){
        diceForSale.Clear();
        foreach(Dice d in starterDiceForSale){
            Dice newdice = Object.Instantiate(d) as Dice;//clone that d
            diceForSale.Add(newdice);
        }
    }
    public void ResetPreviousGoldGained(){
        //we have this overcomplicated system so we can have multiple enemies drop gold
        //and still show the right amount before getting to the shop.
        previousGoldGained.Value = 0;
        //This event could happen each round, or it could happen when we open the shop.
        //if the latter, it shows us how much we've earned since last visiting the shop.
    }
    public void OnEnemyDroppedLoot(int gold){
        playerGold.Value = playerGold.Value + gold;
        previousGoldGained.Value = previousGoldGained.Value + gold;
    }
    public void PlayerSelectedDiceToPurchase(Dice d){
        if(playerGold.Value >= d.salePrice){
            diceConsideredForPurchase.Value = d;
        }
    }
    public void PlayerConfirmedPurchase(){
        Dice d = diceConsideredForPurchase.Value;

        if(playerGold.Value < d.salePrice){
            return;//dont cheat the system. This... shouldn't ever happen, we do the check before. But maybe they click on a dice in the background or something.
        }

        //chaching
        playerGold.Value = playerGold.Value - d.salePrice;

        if(diceForSale.Contains(d)){
            //diceForSale.Remove(d);
            Dice d2 = Instantiate(d) as Dice;//clone it.
            playerBagOfDice.Add(d2);
        }else{
            Debug.LogError("shit we confirmed purchase when shouldn't have?");
        }
        diceConsideredForPurchase.Value = null;
        UpdateShopDiceVisuals.Raise();
    }
}
