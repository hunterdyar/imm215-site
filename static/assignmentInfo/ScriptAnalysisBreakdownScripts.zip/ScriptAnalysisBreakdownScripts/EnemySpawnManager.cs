﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ScriptableObjectArchitecture;
using Pathfinding;
using UnityEngine.Tilemaps;
public class EnemySpawnManager : MonoBehaviour
{
    public GameObjectCollection possibleEnemyPrefabs;
    public Vector2IntReference playerPosition;
    public MovingEnemyCollection allEnemies;
    public GameObject placeHolderGameObject;
    Tilemap tilemap;
    List<TilemapNode> validSpawnLocations;
    bool updating = false;
    void Start(){
        tilemap = TilePathSeeker.tilemap;
    }
    public void SpawnNewEnemy()
    {
        
        StartCoroutine(SpawnEnemy());
    }
    IEnumerator SpawnEnemy(){
        while(updating){
            yield return null;
        }
        if(validSpawnLocations.Count>0){ 
            Vector3 location = GetRandomValidLocationInWorldSpace();
            GameObject prefab = possibleEnemyPrefabs[(int)Random.Range(0,possibleEnemyPrefabs.Count)];
            PreSpawnPlaceholder pre = GameObject.Instantiate(placeHolderGameObject,location,Quaternion.identity).GetComponent<PreSpawnPlaceholder>();
            pre.prefab = prefab;
            pre.location = location;
            // pre.turnsUntilSpawn = 1;
        }
    }
    public void RefreshValidSpawnLocationsSlowly(){//Get call after the player placed something.
        Debug.Log("slowly refresh valid enemy spawn locations");

        StartCoroutine(FindAllSpawnLocations(false));
    }
    public void RefreshValidSpawnLocationsNow(){
        Debug.Log("quickly refresh valid enemy spawn locations");
        StartCoroutine(FindAllSpawnLocations(true));
    }
    IEnumerator FindAllSpawnLocations(bool immedeatly){
        validSpawnLocations = new List<TilemapNode>();
        updating = true;
        
        foreach(TilemapNode spot in TilePathSeeker.graph.allNodes){
            
            bool overlappingEnemy = false;
            foreach(MovingEnemy enemy in allEnemies){
                if(enemy.currentNode == spot){
                    overlappingEnemy = true;
                    break;
                }
            }
            if(!overlappingEnemy){
                if(TilePathSeeker.CheckPath(playerPosition.Value,(Vector2Int)spot.cellPosition,-1)){
                    validSpawnLocations.Add(spot);
                    
                }
                if(!immedeatly){
                        yield return new WaitForEndOfFrame();
                }
            }
        }
        updating = false;
        yield return null;
    }
    public Vector3 GetRandomValidLocationInWorldSpace(){
        if(validSpawnLocations == null){
            RefreshValidSpawnLocationsNow();
        }
        if(validSpawnLocations.Count == 0){
            //return GameObject.FindGameObjectWithTag("Player").transform.position;
            return TilePathSeeker.tilemap.CellToWorld((Vector3Int)playerPosition.Value);
        }
        return validSpawnLocations[(int)Random.Range(0,validSpawnLocations.Count)].offsetWorldPosition;
    }
}
