﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class Exit : MonoBehaviour
{
    DungeonMaster dm;
    Collider2D col;
    public ContactFilter2D contactFilter;
    void OnEnable()
    {
        DungeonMaster.PostPlayerMove += CheckSelf;
        DungeonMaster.PostWorldMove += CheckSelf;
    }
    void OnDisable(){
        DungeonMaster.PostPlayerMove -= CheckSelf;
        DungeonMaster.PostWorldMove -= CheckSelf;
    }
    void Awake(){
        dm = GameObject.FindObjectOfType<DungeonMaster>();
        col = GetComponent<Collider2D>();
        if(!gameObject.CompareTag("Exit")){
            if(!GetComponent<Door>()){
                Debug.LogWarning("Uh oh! Exit object doesnt have exit tag.",this);
            }
        }
    }
    void CheckSelf(){
        Collider2D[] results = new Collider2D[5];
        int overlaps = col.OverlapCollider(contactFilter,results);
        for(int i = 0;(i<overlaps && i<results.Length);i++){
            if(results[i].tag == "Player"){
                    dm.PlayerAtExit();
                    return;
            }else if (results[i].tag == "Pushable"){
                dm.PushableAtExit(new Vector2(transform.position.x,transform.position.y));
            }
        }
    }
}
