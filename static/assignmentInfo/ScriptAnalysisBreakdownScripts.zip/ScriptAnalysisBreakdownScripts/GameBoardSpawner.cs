using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Blooper.Reversi;
public class GameBoardSpawner : MonoBehaviour
{
    public GameObject spacePrefab;
    public Board board;
    public void CreatePieces(){
        foreach(Transform child in transform){
            Destroy(child.gameObject);
        }
        ///
        foreach(KeyValuePair<Vector2,Tile> space in board.board){
            GameObject sp = GameObject.Instantiate(spacePrefab,WorldPosFromGamePos(space.Key),Quaternion.identity,transform);
            sp.GetComponent<BoardSpace>().tile = space.Value;
            sp.GetComponentInChildren<DrawTile>().type = space.Value.type;
        }
    }

    public Vector3 WorldPosFromGamePos(Vector2 point){
        return transform.TransformPoint((Vector3)point);
    }
}