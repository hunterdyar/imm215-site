﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class DungeonTemplate{
    public GameObject finalBossEnemy;
    public int bossLevel;
    public List<GameObject> CritPathEnemies;
    public List<GameObject> extraEnemies;
    public Vector2 dungeonSize;
    public int[] critPathEnemyLevels;
    public int[] extraEnemyLevels;
    public int randomUpDownLineLooper;
    public int randomLeftRightLineLooper;
    public int randomFullConnections;
    public int minimumTotalChests;
    public int minimumTotalEnemies;
    public int critPathLength;
}

public class GenerateDungeon : MonoBehaviour
{
    public List<DungeonTemplate> dungeonLevels;
    private int enemyLevelIndex = 0;
    private int extraEnemyLevelIndex = 0;
    public List<Vector2> dirs = new List<Vector2>{Vector2.up,Vector2.left,Vector2.right,Vector2.left,Vector2.right, Vector2.down, Vector2.down};//no down yet.
    Vector2 previousDirection = Vector2.zero;
    int consecutiveHoriz = 0;
    public IntReference currentDungeonLevel;
    Dictionary<Vector2, DungeonRoom> referenceMap = new Dictionary<Vector2, DungeonRoom>();

    //public void createEnemyLevels
    public List<DungeonRoom> GenerateSimpleDungon(){
        return GenerateSimpleDungon(dungeonLevels[currentDungeonLevel.Value-1]);
    }
    public List<DungeonRoom> GenerateSimpleDungon(DungeonTemplate gen){
        int totalEnemies = 0;
        int totalChests = 0;
        int enemyIndex = 0;
        enemyLevelIndex = 0;
        extraEnemyLevelIndex = 0;
        referenceMap = new Dictionary<Vector2, DungeonRoom>();

        DungeonRoom previousRoom;

        //Create the first room.
        DungeonRoom newroom = ScriptableObject.CreateInstance<DungeonRoom>();
        newroom.position = new Vector2((int)Random.Range(0,gen.dungeonSize.x),0);
        newroom.playerIsHere = true;
        previousRoom = newroom;
        //add to map.
        referenceMap[newroom.position] = newroom;


        //Distribute enemies along path
        bool[] enemyAtIndex = FindIndexes(gen.critPathLength,gen.CritPathEnemies.Count);
        Shuffle(enemyAtIndex);
        //snake up the room.
        
        for(int i = 0;i<gen.critPathLength;i++){
            previousRoom = GrowARoomFromSnake(previousRoom,gen);
            if(enemyAtIndex[i]){
                previousRoom.enemyIsHere = true;
                previousRoom.enemyPrefab = gen.CritPathEnemies[enemyIndex];
                previousRoom.enemyLevel = gen.critPathEnemyLevels[enemyLevelIndex];
                enemyLevelIndex++;
                enemyIndex++;
                totalEnemies++;
            }

            //should we do this here or in the function above?
            referenceMap[previousRoom.position] = previousRoom;
        }

        
        //Add the final boss room.
        DungeonRoom lastroom = ScriptableObject.CreateInstance<DungeonRoom>();
        lastroom.position = previousRoom.position+Vector2.up;
        lastroom.enemyIsHere = true;
        lastroom.enemyPrefab = gen.finalBossEnemy;
        lastroom.enemyLevel = gen.bossLevel;
        totalEnemies++;
        lastroom.finalRoom = true;
        ConnectTwoRooms(previousRoom,lastroom);
        previousRoom = lastroom;
        //add to map.
        referenceMap[lastroom.position] = lastroom;

        //Add the exit stairs above the final boss.
        DungeonRoom stairs = ScriptableObject.CreateInstance<DungeonRoom>();
        stairs.position = lastroom.position+Vector2.up;
        stairs.stairsHere = true;
        lastroom.finalRoom = true;//there can be multiple final rooms, prevents enemies and chests from spawning here.
        ConnectTwoRooms(stairs,lastroom);
        previousRoom = stairs;//not needed?
        referenceMap[stairs.position] = stairs;//add to map.


        //Lets add some jerps 
        for(int i = 0;i<gen.randomLeftRightLineLooper;i++){
            AddRandomLeftRightLine(1,gen);
        }
        for(int i = 0;i<gen.randomUpDownLineLooper;i++){
            AddRandomUpDownLine(1,gen);
        }

        //Turn into normal list and return.
        List<DungeonRoom> map = new List<DungeonRoom>();
        foreach(DungeonRoom r in referenceMap.Values){
            map.Add(r);
        }

        for(int i = 0;i<gen.randomFullConnections;i++){
           map[Random.Range(0,map.Count)].FindMyConnections(map);
        }

        //Add loot and a guarding monster in the room before the loot.
        foreach(DungeonRoom r in map){
            if(r.connections.Count == 1 && r.playerIsHere == false && r.finalRoom == false && r.enemyIsHere == false){
                //put a chest here, or dice, or whatever.
                r.chestIsHere = true;
                totalChests++;
                r.chestLevel = gen.extraEnemyLevels[extraEnemyLevelIndex];
                //how do loot?
                if(r.connections[0].enemyIsHere != true){
                    //put an enemy here.
                    r.connections[0].enemyIsHere = true;
                    r.connections[0].enemyPrefab = gen.extraEnemies[Random.Range(0,gen.extraEnemies.Count)];
                    r.connections[0].enemyLevel = gen.extraEnemyLevels[extraEnemyLevelIndex];
                    extraEnemyLevelIndex++;
                    totalEnemies++;
                }
            }
        }

        //Validation checks.

        //Validate test A: do we have enough enemies?
        
        if(totalEnemies < gen.minimumTotalEnemies){
            //recursively try again.
            for(int i = 0;i<(10-totalEnemies);i++){
                DungeonRoom testr = map[Random.Range(0,map.Count)];
                if(!testr.enemyIsHere && !testr.playerIsHere && !testr.chestIsHere){
                        testr.enemyIsHere = true;
                        testr.enemyPrefab = gen.extraEnemies[Random.Range(0,gen.extraEnemies.Count)];
                        testr.enemyLevel = gen.extraEnemyLevels[extraEnemyLevelIndex];
                        extraEnemyLevelIndex++;
                        totalEnemies++;
                }
            }
        }
        //validate 2, do we have enough chests?
        if(totalChests < gen.minimumTotalChests){
            //recursively try again.
            for(int i = 0;i<(7-totalChests);i++){
                DungeonRoom testr = map[Random.Range(0,map.Count)];
                if(!testr.enemyIsHere && !testr.playerIsHere && !testr.chestIsHere){
                        testr.chestIsHere = true;
                        testr.chestLevel = Mathf.RoundToInt(Random.Range(1,gen.bossLevel));
                }
            }
        }

        return map;
        
    }
    private void AddRandomLeftRightLine(int lineLength,DungeonTemplate gen){
        //Random left or right.
        Vector2 dir = Vector2.left;
        if(Random.value > 0.5f){
            dir = Vector2.right;
        }
        //first get a random room in the map.
        List<Vector2> keyList = new List<Vector2>(referenceMap.Keys);
        
        DungeonRoom randomRoom = referenceMap[keyList[(int)Random.Range(0,referenceMap.Count-1)]];
        while(randomRoom.finalRoom == true || randomRoom.criticalPath == false || randomRoom.stairsHere == true){
            randomRoom = referenceMap[keyList[(int)Random.Range(0,referenceMap.Count-1)]];
        }
        //Now, try to add a line. if theres already a room there, connect them and give up.
        for(int i = 0;i<=lineLength;i++){
            Vector2 newk= randomRoom.position+dir;
            if(keyList.Contains(newk)){
                ConnectTwoRooms(randomRoom,referenceMap[newk]);
                break;
            }else{
                DungeonRoom newroom = ScriptableObject.CreateInstance<DungeonRoom>();
                newroom.position = newk;
                newroom.criticalPath = false;
                referenceMap[newk] = newroom; 
                ConnectTwoRooms(randomRoom,newroom);
                randomRoom = newroom;
            }
            
        }
    }

        private void AddRandomUpDownLine(int lineLength, DungeonTemplate gen){
        //Random up or down.
        Vector2 dir = Vector2.down;
        if(Random.value > 0.5f){
            dir = Vector2.up;
        }
        //first get a random room in the map.
        List<Vector2> keyList = new List<Vector2>(referenceMap.Keys);
        DungeonRoom randomRoom = referenceMap[keyList[(int)Random.Range(0,referenceMap.Count-1)]];
        while(randomRoom.finalRoom == true || randomRoom.criticalPath == false){
            randomRoom = referenceMap[keyList[(int)Random.Range(0,referenceMap.Count-1)]];
        }
        //Now, try to add a line. if theres already a room there, connect them and give up.
        for(int i = 0;i<=lineLength;i++){
            Vector2 newk= randomRoom.position+dir;
            if(dir.y>gen.dungeonSize.y-1){
                break;
            }
            if(keyList.Contains(newk)){
                ConnectTwoRooms(randomRoom,referenceMap[newk]);
                break;
            }else{
                DungeonRoom newroom = ScriptableObject.CreateInstance<DungeonRoom>();
                newroom.position = newk;
                newroom.criticalPath = false;
                referenceMap[newk] = newroom; 
                ConnectTwoRooms(randomRoom,newroom);
                randomRoom = newroom;
            }
            
        }
    }
    private DungeonRoom GrowARoomFromSnake(DungeonRoom prev,DungeonTemplate gen){
        if(previousDirection == Vector2.up){
            dirs.Remove(Vector2.up);
        }else{
            if(!dirs.Contains(Vector2.up)){
                dirs.Add(Vector2.up);
            }
        }
        Vector2 dir = dirs[Random.Range(0,dirs.Count)];
        Vector2 newpos = prev.position + dir;
        if(newpos.x < 0 || newpos.x > gen.dungeonSize.x){
            if(previousDirection == Vector2.up){
                //Get us out of here.
                if(newpos.x <0){
                    dir = Vector2.right;
                }else if(newpos.x > gen.dungeonSize.x){
                    dir = Vector2.left;
                }else{
                    Debug.LogError("hmm");
                }
            }else if(dir == Vector2.left || dir == Vector2.right){
                dir = -dir;
                newpos = prev.position+dir;
                if(referenceMap.ContainsKey(newpos)){
                    dir=Vector2.up;            //newpos = prev.position + dir;
                }
            }else{
                dir=Vector2.up;
            }
        }

        if(consecutiveHoriz >= 3){
            dir = Vector2.up;
        }
        
        if(referenceMap.ContainsKey(newpos)){
            if(dir == Vector2.left || dir == Vector2.right){
                dir = -dir;
                newpos = prev.position+dir;
                if(referenceMap.ContainsKey(newpos)){
                    dir=Vector2.up;            //newpos = prev.position + dir;
                }
            }            //newpos = prev.position + dir;
        }
        
        newpos = prev.position+dir;
        previousDirection = dir;
        if(dir == Vector2.left || dir == Vector2.right){
            consecutiveHoriz++;
        }else{
            consecutiveHoriz = 0;
        }
        if(referenceMap.ContainsKey(newpos)){
            Debug.LogError("shit");
        }
        DungeonRoom newroom = ScriptableObject.CreateInstance<DungeonRoom>();
        newroom.position = newpos;
        newroom.criticalPath = true;
        newroom.name = newpos.ToString();
        ConnectTwoRooms(prev,newroom);
        
        return newroom;
    }
    void ConnectTwoRooms(DungeonRoom a, DungeonRoom b){
        if(!a.connections.Contains(b)){
            a.connections.Add(b);
        }
        if(!b.connections.Contains(a)){
            b.connections.Add(a);
        }
        a.FindMyConnectionDirections();
        b.FindMyConnectionDirections();
    }
    static bool[] FindIndexes(int n, int r) {
        bool[] arrayWithObjects = new bool[n];
        int quotient = (n-1) / (r-1);
        int remainder = (n-1) % (r-1);
        int index = 0;
        do {
            arrayWithObjects[index] = true;
        } while( (index += quotient + (remainder-- > 0 ? 1 : 0)) < n );
        return arrayWithObjects;
    }
    void Shuffle(bool[] alpha)
	{
		for (int i = 0; i < alpha.Length; i++) {
            bool temp = alpha[i];
            int randomIndex = Random.Range(i, alpha.Length);
            alpha[i] = alpha[randomIndex];
            alpha[randomIndex] = temp;
        }
	}
}
