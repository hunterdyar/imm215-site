﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityWell : MonoBehaviour {

	List<Rigidbody2D> moons;
	Transform here;
	[SerializeField]
	private float wellModifier = 0.1f;
	// Use this for initialization
	void Start () {
		moons = new List<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		foreach (Rigidbody2D moon in moons){

			if (moon == null){//if the object has been destoryed before being removed from the list. Like a bullet hitting a wall inside the collider.
				moons.Remove(moon);
			}else{
				Vector2 gravityVec = (transform.position - moon.transform.position);//The difference between positions gives us a vector pointing towards the well.
				if(magnitude < 1f){
					magnitude = 1f;//if you pass "through" the center of the well crazy shit happens and you accelerate like a mofo. This stops that.
				}
				float magnitudeModifier = 1 / Mathf.Pow(magnitude, 2f);//The power is inversly proportional to the distance (squared). Because it's gravity.

				gravityVec.Normalize();//Since our distance power has been calculated above, normalize so this is just direction.

				moon.AddForce(gravityVec*magnitudeModifier*wellModifier,ForceMode2D.Force);
			}
		}
	}

	void OnTriggerEnter2D(Collider2D col){
		moons.Add(col.gameObject.GetComponent<Rigidbody2D>());
	}
	void OnTriggerExit2D(Collider2D col){
		moons.Remove(col.gameObject.GetComponent<Rigidbody2D>());
	}
}
