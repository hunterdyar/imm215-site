﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ScriptableObjectArchitecture;
using Cinemachine;
using UnityEngine.SceneManagement;
public class HoleSwitcher : MonoBehaviour
{
    public int startingLevel = 0;
    public IntReference score;
    public IntReference gameType;
    public StringReference currentHoleName;
    public int currentHole = 0;
    public List<Hole> holes = new List<Hole>();
    [Header("Events")]
    public Vector3GameEvent SetPlayerPositionEvent; 

    void Start()
    {
        score.Value = 0;
        InitHole(startingLevel);
    }

    public void PlayerDied(string deathType){
        Debug.Log("player died");
        score.Value = 0;
        currentHole = startingLevel;
        StartCoroutine(RestartGame());
        //InitHole(startingLevel);
    }

    public void GoToNextHole(int status){
        currentHole++;
        score.Value = (int)((int)score.Value + 1 - (int)status);
        if(currentHole > holes.Count -1){
           StartCoroutine(EndGame());
           return;
        }
            InitHole(currentHole);
        
    }
    IEnumerator RestartGame(){
        yield return new WaitForSeconds(2f);
        SceneManager.LoadScene("Game2D");
    }
    IEnumerator EndGame(){
        yield return new WaitForSeconds(2f);
        if(gameType.Value == 0){
            SceneManager.LoadScene("WinEasy");
        }else if(gameType.Value == 1){
            SceneManager.LoadScene("WinGauntlet");
        }
    }
    void InitHole(int holeIndex){
        if(holes[holeIndex] != null){
            SetPlayerPositionEvent.Raise(holes[holeIndex].playerStartPosition.position);
            currentHoleName.Value = holes[holeIndex].holeName;
            // foreach(Hole h in holes){
            //     h.cam.Priority = 0;
            // }
            for(int i = 0;i<holes.Count;i++){
                holes[i].cam.Priority = 1;
            }
            holes[holeIndex].cam.Priority = 10;
        }
    }
    // Update is called once per frame
    void Update()
    {
        if(Input.GetButtonDown("Escape")){
            SceneManager.LoadScene("Menu");
        }
        if(Input.GetButtonDown("Restart")){
            SceneManager.LoadScene("Game2D");
        }
    }

    [ContextMenu("Update Holes Array")]
    void UpdateHolesArray(){
        holes.Clear();
        foreach(Transform child in transform){
            if(child.GetComponent<Hole>()){
                holes.Add(child.GetComponent<Hole>());
            }
        }
    }
}
