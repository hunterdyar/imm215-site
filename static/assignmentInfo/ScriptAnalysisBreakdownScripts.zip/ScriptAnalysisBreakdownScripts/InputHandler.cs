﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputHandler : MonoBehaviour
{

	List<Vector2> inputStack = new List<Vector2>();
    DungeonMaster dm;

    void Awake()
    {
        dm = GetComponent<DungeonMaster>();
    }
    
	public void StackPlayerInput(){
		if(Input.GetButtonDown("Left") == true){
			inputStack.Add(Vector2.left);
		}else if(Input.GetButtonDown("Right") == true){
			inputStack.Add(Vector2.right);
		}else if(Input.GetButtonDown("Up") == true){
			inputStack.Add(Vector2.up);
		}else if(Input.GetButtonDown("Down") == true){
			inputStack.Add(Vector2.down);
		}
	}
    public void ClearInputStack(){
		inputStack = new List<Vector2>();
	}
    public void CheckForPlayerInput(){
		if(inputStack.Count>0){
				Vector2 move = inputStack[0];
				inputStack.RemoveAt(0);
				TryMove(move);//this might clear the input stack, like if we hit a wall, so we save it first.
				//smashing buttons when one does hit a wall is, oddly enough, the most common use of the stack.
		}else if(Input.GetButtonDown("Left") == true){
				TryMove(Vector2.left);
			}else if(Input.GetButtonDown("Right") == true){
				TryMove(Vector2.right);
			}else if(Input.GetButtonDown("Up") == true){
				TryMove(Vector2.up);
			}else if(Input.GetButtonDown("Down") == true){
				TryMove(Vector2.down);
			}
		}
    void Update()
    {
		if(Input.GetButton("Camera Shift")){
			return;
		}
        if(dm.state == 0){
            CheckForPlayerInput();
        }else if(dm.state != 6 && dm.state > 0){
            StackPlayerInput();
        }
    }
    void TryMove(Vector2 move){
		if(dm.state != 6){
        	if(dm.TryPlayerMove(move)){
				//change state if succesful.
				dm.state = 1;
			}
		}
    }
}
