﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LickableObject : MonoBehaviour
{
    #region Serialize fields

    [SerializeField, Range(0.0f, 1.0f)]
    private float spinRate = 0.5f;

    [SerializeField]
    private float maxInsightRange = 1f;

    [SerializeField]
    private float rareInsightRange = 10f;

    [SerializeField]
    private float medInsightRange = 25f;

    [SerializeField]
    private Vector4 insightAmounts = new Vector4(100.0f, 50.0f, 25.0f, 10.0f);

    [Header("SFX")]
    [SerializeField]
    AudioClip maxClip;

    [SerializeField]
    AudioClip rareClip;

    [SerializeField]
    AudioClip medClip;

    [SerializeField]
    AudioClip regClip;

    #endregion

    #region Public fields

    [HideInInspector]
    public bool pauseRot;

    [HideInInspector]
    public AudioSource audioSrc;

    #endregion

    #region Private fields

    float[] insightRegions;

    #endregion

    #region Unity events
    private void Awake() {
        ResetInsightRegions();
        pauseRot = false;
        audioSrc = GetComponent<AudioSource>();
    }

    private void Update() {
        // rotate object by spin rate
        if (!pauseRot) {
            transform.Rotate(new Vector3(0, spinRate, 0));
        }
    }
    #endregion

    #region Private methods

    // Insight regions based on arc angle 
    void ResetInsightRegions() {
        float maxInsight = Random.Range(0.0f, 360.0f);
        float rareInsight = Random.Range(0.0f, 360.0f);
        while (maxInsight - maxInsightRange <= rareInsight && rareInsight <= maxInsight + maxInsightRange) {
            rareInsight = Random.Range(0.0f, 360.0f);
        }

        float medInsight = Random.Range(0.0f, 360.0f);
        while ((maxInsight - maxInsightRange <= medInsight && medInsight <= maxInsight + maxInsightRange) ||
               (rareInsight - rareInsightRange <= medInsight && medInsight <= rareInsight + rareInsightRange)) {
            medInsight = Random.Range(0.0f, 360.0f);
        }

        insightRegions = new float[] { maxInsight, rareInsight, medInsight };
        //Debug.Log("Insight locations: { " + maxInsight + ", " + rareInsight + ", " + medInsight + "}");
    }

    #endregion

    #region Public methods

    public float GetInsight(float angle) {
        float maxInsight = insightRegions[0];
        float rareInsight = insightRegions[1];
        float medInsight = insightRegions[2];

        if (maxInsight - maxInsightRange <= angle && angle <= maxInsight + maxInsightRange) {
            audioSrc.clip = maxClip;
            audioSrc.Play();
            ResetInsightRegions();
            return insightAmounts[0];
        } else if (rareInsight - rareInsightRange <= angle && angle <= rareInsight + rareInsightRange) {
            audioSrc.clip = rareClip;
            audioSrc.Play();
            ResetInsightRegions();
            return insightAmounts[1];
        } else if (medInsight - medInsightRange <= angle && angle <= medInsight + medInsightRange) {
            audioSrc.clip = medClip;
            audioSrc.Play();
            ResetInsightRegions();
            return insightAmounts[2];
        }

        //Debug.Log("hit low");
        audioSrc.clip = regClip;
        audioSrc.Play();
        return insightAmounts[3];
    }

    #endregion
}
