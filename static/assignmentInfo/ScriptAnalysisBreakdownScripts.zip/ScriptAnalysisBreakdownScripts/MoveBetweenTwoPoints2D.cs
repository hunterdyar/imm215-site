﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveBetweenTwoPoints2D : MonoBehaviour
{
    public Transform posA;
    public Transform posB;
    public AnimationCurve movementCurve;
    public float timeToMove;
    public float timeBetweenMoves;
    Vector3 va;
    Vector3 vb;
    Rigidbody2D rigidbody;
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        va = posA.position;
        vb = posB.position;
        StartCoroutine(LerpPosition());
    }

    IEnumerator LerpPosition(){
        while(true){
            float t = 0;
            while (t<1){
                rigidbody.MovePosition(Vector3.Lerp(va,vb,movementCurve.Evaluate(t)));
                t = t+Time.deltaTime/timeToMove;
                yield return null;
            }
            rigidbody.MovePosition(vb);
            yield return new WaitForSeconds(timeBetweenMoves);
            t = 0;
            while (t<1){
                rigidbody.MovePosition(Vector3.Lerp(vb,va,movementCurve.Evaluate(t)));
                t = t+Time.deltaTime/timeToMove;
                yield return null;
            }
            rigidbody.MovePosition(va);
            yield return new WaitForSeconds(timeBetweenMoves);
        }
    }
}
