﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Piece : MonoBehaviour
{
    
    public float health = 100;
    public bool isOn = true;
    public bool canTurnOff = true;
    public bool canTurnOn{get {return canTurnOff;}set{canTurnOff = value;}}
    public string title;
    public int maxLevel = 3;
    public Vector3 baseDailyGains = Vector3.zero;
    public virtual Vector3 dailyGains{get{return baseDailyGains;}}
    public ConstructonManager.PieceType pieceTypeRef;
    public PieceManager pm;
    public Node currentNode;
    [HideInInspector]
    public ActionManager am;
    public float MaterialsOnDeconstruct;
    public Actions[] availableActions;
    public bool canBeDeconstructed = true;
    public int level = 1;
    public float costToUpgrade = 10;
    Animator anim;
    public float distanceToPlayer{
        get {return (transform.position - ActionManager.player.transform.position).magnitude;}    
    }
    public float chebyshevDistance{
        get {
            return Mathf.Max(Mathf.Abs(ActionManager.player.transform.position.x - transform.position.x),Mathf.Abs(ActionManager.player.transform.position.z - transform.position.z));
        }
    }
    public void HealthCheck(){
        if(health <= 0){
            Destroy(gameObject);
        }
    }

    void OnEnable(){
        anim = GetComponent<Animator>();
        ActionManager.OnNewDay += NewDay;
    }
    void Start(){
        if(anim != null){
            //anim.SetTrigger()
        }
    }
    void OnDisable(){
        ActionManager.OnNewDay -= NewDay;
    }
    public virtual void NewDay(){
        //if(isOn){}
        
    }
    public virtual void UpdateGains(){
        //update gains here?
    }
    
    // Start is called before the first frame update
    void Awake(){
        PieceManager.AddPieceToArmy(this);  
        am = GameObject.FindObjectOfType<ActionManager>();
        SetCurrentNode();
        if(availableActions.Length == 0){
            availableActions = (Actions[])System.Enum.GetValues(typeof(Actions));
        }
    }
    public bool SetCurrentNode(){
        GameObject[] allnodes = GameObject.FindGameObjectsWithTag("navPoint");
        foreach(GameObject n in allnodes){
            if((n.transform.position - transform.position).magnitude <0.25f){
                currentNode = n.GetComponent<Node>();
                currentNode.pieceHere = this;
                return true;
            }
        }
        return false;
    }

    public void Deconstruct(){
        PieceManager.RemovePieceFromArmy(this);
        Resources.GetMaterials(MaterialsOnDeconstruct);
        Destroy(gameObject);
    }
    public void Repair(){
        float costToRepair = CostToRepair();
           if(costToRepair <= Resources.material){
            Resources.SpendMaterial(costToRepair);
            health = 100;
        }
    }
    public float CostToRepair(){
        return pieceTypeRef.materialCost*0.75f*(1-(health/100));
    }
    public virtual bool Upgrade(){
        if(costToUpgrade <= Resources.material && level <= maxLevel){
            Resources.SpendMaterial(costToUpgrade);
            level++;
            return true;
        }else{
            return false;
        }
    }
    void OnDestroy(){
        SidebarMenu.CreateMenu();
    }
}
