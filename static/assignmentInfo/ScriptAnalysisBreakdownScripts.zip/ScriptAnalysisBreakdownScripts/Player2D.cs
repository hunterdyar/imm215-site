﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ScriptableObjectArchitecture;
public class Player2D : MonoBehaviour
{

    public float speedThreshold;
    public AnimationCurve linearDragCurve;
    public AnimationCurve lerpToHolesCurve;
    public StringGameEvent playerDiedEvent;
    public FloatGameEvent bonkSound;
    public FloatGameEvent sinkSound;
    public FloatGameEvent plopSound;
    public IntGameEvent playerFinishedCurrentHole;
    public BoolReference turnPlayable; 
    public IntReference gameType;

    Material invertMat;
    public Material travelingMat;
    Rigidbody2D rb;
    Collider2D col;
    bool inHole = false;
    bool dying = false;
    int loserTest = 0;
    InputHandler2D ih2d;
    bool firstHole = true;
    MeshRenderer mr;
    TrailRenderer tr;
    int hazardTimer = 0;
    float backupHoleTimer = 0f;
    bool plopped = false;
    void Awake()
    {
        mr = GetComponentInChildren<MeshRenderer>();
        invertMat = mr.material;
        tr = GetComponentInChildren<TrailRenderer>();
        tr.enabled = false;
        ih2d = GetComponent<InputHandler2D>();
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<CircleCollider2D>();
    }

    public void ResetStatus(){
        inHole = false;
        dying = false;
        loserTest = 0;
        hazardTimer = 0;
        backupHoleTimer = 0;
        ih2d.ResetInputForNewHole();
        plopped = false;
        //mr.enabled = true;
    }
    public void ResetPlayerPosition(Vector3 newPos){
        if(firstHole){
            firstHole = false;
            transform.position = newPos;
            tr.enabled = true;
            ResetStatus();
        }else{
            StartCoroutine(LerpToNextHolePosition(transform.position,newPos));
        }
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        rb.drag = linearDragCurve.Evaluate(rb.velocity.magnitude/10);
        if(rb.velocity.magnitude < speedThreshold && !inHole && !turnPlayable.Value){
            loserTest++;
        }else{
            loserTest = 0;
        }
    }
    void Update(){
        if(loserTest > 10 && gameType.Value == 0){
            if(mr.isVisible){
                playerFinishedCurrentHole.Raise(0);
                ResetStatus();
            }else{
                playerDiedEvent.Raise("gone");
                dying = true;
                StartCoroutine(FadeBallOut());
                ResetStatus();
            }
        }else if (loserTest > 10 && gameType.Value == 1 && !dying){
            playerDiedEvent.Raise("Missed");
            dying = true;
            //plopSound.Raise();
            StartCoroutine(FadeBallOut());
            ResetStatus();
        }else if(hazardTimer == 10 && !dying){
            playerDiedEvent.Raise("Water");
            dying = true;
            StartCoroutine(FadeBallOut());
        }
        if(backupHoleTimer > 2f && !inHole){
            playerFinishedCurrentHole.Raise(1);
            sinkSound.Raise(1);
            inHole = true;
        }
    }

     void OnTriggerStay2D(Collider2D col){
        if(col.tag == "Water"){
            if(col.OverlapPoint((Vector2)transform.position)){//overlapping the center point
    
                Vector2 boxPoints1 = (Vector2)transform.position+new Vector2(transform.localScale.x/2,0);
                Vector2 boxPoints2 = (Vector2)transform.position-new Vector2(transform.localScale.x/2,0);
                Vector2 boxPoints3 = (Vector2)transform.position+new Vector2(0,transform.localScale.y/2);
                Vector2 boxPoints4 = (Vector2)transform.position-new Vector2(0,transform.localScale.y/2);

                if(col.OverlapPoint(boxPoints1) && col.OverlapPoint(boxPoints2) && col.OverlapPoint(boxPoints3) && col.OverlapPoint(boxPoints4)){
                    if(!plopped){
                        plopSound.Raise(1);
                        plopped = true;
                    }
                    hazardTimer++;
                    rb.AddForce(-rb.velocity.normalized*40);//fake increase drag without extra variables.
                }else{
                    //override angular drag and set it to 0, for a nifty "PLOP"
                }
                
            }
        }
        if(col.tag == "Hole"){
            backupHoleTimer = backupHoleTimer + Time.deltaTime;
            float holeSize = col.transform.localScale.x;
            float dtoaces = (new Vector2(col.transform.position.x,col.transform.position.y) - new Vector2(transform.position.x,transform.position.y)).magnitude;
            if(dtoaces > 0.5f*holeSize){
               // rb.mass = 1;
                rb.AddForce((col.transform.position-transform.position)*60);
            }else if(dtoaces < 0.2f*holeSize && rb.velocity.magnitude < 0.1f && !inHole){
               // rb.mass = 1;//reset
               //SNAP
               rb.velocity = Vector2.zero;
               rb.MovePosition(col.transform.position);
                playerFinishedCurrentHole.Raise(1);
                sinkSound.Raise(1);
                inHole = true;
            }else{
               // rb.mass = 0;
                rb.AddForce((col.transform.position-transform.position)*300);
                rb.AddForce(-rb.velocity.normalized*40);//fake increase drag without extra variables.
            }
        }
//         if(hazardTimer >= timeInHoleToWin*3 && col.tag == "Water"){
//             playerDiedEvent.Raise("Water");
//         }
//         if(holeTimer >= timeInHoleToWin && col.tag == "Hole"){
//             playerFinishedCurrentHole.Raise(1);
// W        }
    }

        IEnumerator LerpToNextHolePosition(Vector3 startPos, Vector3 endPos){
        mr.material = travelingMat;
        float t = 0;
        tr.enabled = false;
        col.enabled = false;
        while (t<1){
            transform.position = Vector3.Lerp(startPos,endPos,lerpToHolesCurve.Evaluate(t));
            t = t+Time.deltaTime/1.75f;
            yield return null;
        }
        transform.position = endPos;
        col.enabled = true;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = 0;
        tr.enabled = true;
        mr.material = invertMat;
        ResetStatus();
        yield return null;
    }
        IEnumerator FadeBallOut(){
            Material mat = mr.material;
            Color col = mat.GetColor("_Color");
            float t = 1;
            yield return new WaitForSeconds(0.4f);
            while(t > 0){
                mr.material.SetColor("_Color",new Color(col.r,col.g,col.b,t));
                t = t - Time.deltaTime;
                yield return null;
            }
            tr.enabled = false;
            yield return null;
        }
        void OnCollisionEnter2D(Collision2D col){
            bonkSound.Raise(col.relativeVelocity.magnitude);
        }
}
