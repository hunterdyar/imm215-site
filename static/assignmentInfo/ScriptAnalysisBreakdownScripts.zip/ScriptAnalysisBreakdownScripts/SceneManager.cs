﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ScriptableObjectArchitecture;
using Com.LuisPedroFonseca.ProCamera2D;
using UnityEngine.SceneManagement;
public class SceneManager : MonoBehaviour
{
    [Header("Settings")]
    public bool resetCurrentLevelIndexAtStart = true;


    [Header("References")]
    public BoolReference playerCanDoInput;
    public IntReference currentLevelIndex;
    public SceneCollection levelList;
    public SceneVariable currentScene;
    public MoveCollection currentAvailableMoves;

    [Header("Events")]
    public GameEvent whenSceneGetsLoadedEvent;
    ProCamera2DTransitionsFX transitionFX;
    bool transitionFXExiting = false;
    
    void Awake(){
        transitionFX = GetComponent<ProCamera2DTransitionsFX>();
        transitionFX.OnTransitionExitEnded += OnExitEnded;
        transitionFX.OnTransitionEnterEnded += OnEnterEnded;
        currentAvailableMoves.Clear();
    }
    void Start(){
        if(resetCurrentLevelIndexAtStart){
            currentLevelIndex.Value = 0;//
        }
        LoadScene(levelList[currentLevelIndex.Value],false);
    }
    void Update(){
        //Reload.
        if(Input.GetKeyDown(KeyCode.R)){
            RestartLevel();
        }
    }

    public void WhenPlayerReachesGoal(){
        currentLevelIndex.Value++;
        if(currentLevelIndex.Value == levelList.Count){
            currentLevelIndex.Value = 0;//restart for now?
        }
        LoadScene(levelList[currentLevelIndex.Value],true);
    }
    public void WhenPlayerDies(){
        //Death Counter plus plus
        RestartLevel();
    }
    public void RestartLevel(){
        LoadScene(currentScene,true);
    }

    void LoadScene(SceneVariable sceneToLoad, bool fadeOutFirst)
    {
        StartCoroutine(DoLoadScene(sceneToLoad,fadeOutFirst));
    }
    IEnumerator DoLoadScene(SceneVariable sceneToLoad, bool fadeOutFirst){
        playerCanDoInput.Value = false;
        if(fadeOutFirst){
            transitionFX.TransitionExit();
            transitionFXExiting = true;
            while(transitionFXExiting){
                yield return new WaitForEndOfFrame();
            }
        }
        if(currentScene.Value != null ){//we can assume that if this isnt set, there isnt a scene loaded.
            //if the scene that is currently set is loaded.
            if(UnityEngine.SceneManagement.SceneManager.GetSceneByBuildIndex(currentScene.Value.SceneIndex).isLoaded){
                //unload the scene
                AsyncOperation unloadSceneOperation = UnityEngine.SceneManagement.SceneManager.UnloadSceneAsync(currentScene.Value.SceneName);

                while(!unloadSceneOperation.isDone){
                    yield return new WaitForEndOfFrame();
                }
            }
        }
        AsyncOperation sceneLoad = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(sceneToLoad.Value.SceneName,LoadSceneMode.Additive);
        while(!sceneLoad.isDone){
            yield return new WaitForEndOfFrame();
        }
        transitionFX.TransitionEnter();
        currentScene = sceneToLoad;
        whenSceneGetsLoadedEvent.Raise();
        yield return null;
    }
    void OnExitEnded(){
        transitionFXExiting  = false;
    }
    void OnEnterEnded(){
        playerCanDoInput.Value = true;
    }
}
