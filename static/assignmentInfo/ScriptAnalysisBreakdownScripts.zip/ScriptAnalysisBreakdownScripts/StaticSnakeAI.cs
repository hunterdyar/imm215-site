﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticSnakeAI : MonoBehaviour
{
    public Transform snakeTarget;
    public Transform snakeBase;
    Vector3 snapTarget;//The IKtarget's target.
    Vector3 restPos;
    Vector3 cautiousOffset;
    bool cautious = false;
    public List<GameObject> deathmotes;//Do we have to set this publicly?

    Transform player;
    
    public float snakeLength = 1.2f;//how long the snake things it can reach
    // Start is called before the first frame update
    void Start()
    {
        restPos = snakeTarget.position;//initial position is rest position.
        player = GameObject.FindGameObjectWithTag("Player").transform;
        
        //Set the entity delegate to call this function when the entity is destoyed
        GetComponent<EntityInstance>().doThisOnDeath = WhenDestroyed;
    }

    // Update is called once per frame
    void Update()
    {
        if(!cautious){
            if((player.transform.position - snakeBase.position).magnitude <= snakeLength){
                snapTarget = player.position;
            }else{
                snapTarget = restPos;
            }
        }else{//if cautious
            cautiousOffset = Vector3.Lerp(cautiousOffset,player.position,0.1f*Time.deltaTime);
            snapTarget = player.transform.position+cautiousOffset; 
        }
        snakeTarget.position = Vector3.Lerp(snakeTarget.position,snapTarget,3f*Time.deltaTime);
    }
    void OnCollisionEnter2D(Collision2D col){
        if(col.transform.CompareTag("Player")){
            cautiousOffset = (Vector3)col.GetContact(0).normal*4f;
            cautious = true;
            StartCoroutine(WaitThenRelax(3f));
        }
    }
    IEnumerator WaitThenRelax(float f){
        yield return new WaitForSeconds(f);
        cautious = false;
    }
    void WhenDestroyed(){
        foreach (GameObject mote in deathmotes){
            mote.transform.SetParent(null);
            mote.SetActive(true);
        }
        //How can I pass this as a delagate to the entity script?

        //Create a bunch of triangles that float+spin slowly in random directions
        //Triangles spawn at the visually appropriate places for each private void OnEnable() {
        //triangles shrink and get destroyed
        
        //Move each bone to root, activate deathfloat script
        //that script activates/adds components, gives velocity, shrinks, destroys self. 
        
        //Need a lit of bones.
            
        
    }
}
