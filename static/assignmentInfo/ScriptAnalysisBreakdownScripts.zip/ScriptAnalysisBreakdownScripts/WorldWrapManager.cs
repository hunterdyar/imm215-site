﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WorldWrapManager : MonoBehaviour
{
    // Start is called before the first frame update
    Transform player;
    int rootCount;
    Vector2 currentSceneSpacePosition = Vector2.zero;//starts in scene 0,0
    Vector2 loadingThisSceneSpacePosition;
    List<Vector2> loadedScenes;
    public int currentSceneIndex = 0;
    public List<string> scenesInGame;//We could eventually just use the int of the scene list in the scene manager?
    List<sceneInSpace> sceneSpace;
    float loadedSceneBufferMagnitude = 2f;
    
    int lastLoadedSceneIndex;
    Vector2 sceneSize = new Vector2(50,30);//Offset between scenes.
    Vector2 sceneOffset = Vector2.zero;
    Vector2 sceneBuffer = new Vector2(2,1);//Should be at least half the camera size?
    GameObject[] newRootTransforms;
    bool isLoading = false;
    bool wrap = true;
    struct sceneInSpace{
        public Scene scene;
        public Vector2 pos;
        public int sceneInGameIndex;
    }
    
    void Start()
    {
        //SceneManager.SetActiveScene(SceneManager.GetSceneByName("MasterWorld"));
        loadedScenes = new List<Vector2>();
        loadedScenes.Add(Vector2.zero);//initial Scene.
        sceneSpace = new List<sceneInSpace>();
        sceneInSpace initialSceneInSpace;
        initialSceneInSpace.scene = SceneManager.GetSceneByName(scenesInGame[currentSceneIndex]);
        initialSceneInSpace.pos = Vector2.zero;
        initialSceneInSpace.sceneInGameIndex = currentSceneIndex;
        sceneSpace.Add(initialSceneInSpace);
        rootCount = SceneManager.GetActiveScene().rootCount;
        player = GameObject.FindGameObjectWithTag("Player").transform;
        SceneManager.sceneLoaded += OnSceneLoaded;//run our onsceneloaded function when a scene is loaded.
        StartCoroutine(ConsiderSceneSpace());
    }

    // Update is called once per frame
    void Update()
    {
        currentSceneSpacePosition = new Vector2(Mathf.Floor(player.position.x/sceneSize.x),Mathf.Floor(player.position.y/sceneSize.y));
    }
    IEnumerator ConsiderSceneSpace(){
        while(wrap){
            //We get 0.125f because it's an 8th of a second.
            //It seems unreasonable to ask for a player to travel an entire level more than once a second.
            //We could take the players velocity into account if it becomes an issue.
            ConsiderLoading(currentSceneSpacePosition);
            while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            ConsiderLoading(currentSceneSpacePosition + new Vector2(0,1));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            ConsiderLoading(currentSceneSpacePosition + new Vector2(0,-1));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            ConsiderLoading(currentSceneSpacePosition + new Vector2(1,0));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            ConsiderLoading(currentSceneSpacePosition + new Vector2(-1,0));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            ConsiderLoading(currentSceneSpacePosition + new Vector2(1,1));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            ConsiderLoading(currentSceneSpacePosition + new Vector2(-1,-1));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            ConsiderLoading(currentSceneSpacePosition + new Vector2(1,-1));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            ConsiderLoading(currentSceneSpacePosition + new Vector2(-1,1));
                        while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
            Cleanup();
                       while(isLoading){
                yield return new WaitForEndOfFrame();//if the framerate drops below 1/8 a second we might get bugs.
            }
            yield return new WaitForEndOfFrame();
        }
    }
    void Cleanup(){
        List<sceneInSpace> removeTheseFromLoadedScenes = new List<sceneInSpace>();
        foreach(sceneInSpace s in sceneSpace){
            if(s.sceneInGameIndex != currentSceneIndex){
                if((s.pos-currentSceneSpacePosition).magnitude > 0.5f){
                    SceneManager.UnloadSceneAsync(s.scene);
                    removeTheseFromLoadedScenes.Add(s);
                }
            }else if ((s.pos-currentSceneSpacePosition).magnitude > loadedSceneBufferMagnitude){
                SceneManager.UnloadSceneAsync(s.scene);
                removeTheseFromLoadedScenes.Add(s);
            }
        }
        foreach(sceneInSpace pop in removeTheseFromLoadedScenes){
            loadedScenes.Remove(pop.pos);
            sceneSpace.Remove(pop);
        }
    }
    void ConsiderLoading(Vector2 sceneSpacePos){
            if(!loadedScenes.Contains(sceneSpacePos)){
                loadingThisSceneSpacePosition = sceneSpacePos;//carries into the onSceneLoaded callback.
                loadedScenes.Add(sceneSpacePos);
                isLoading = true;
                SceneManager.LoadSceneAsync(scenesInGame[currentSceneIndex],LoadSceneMode.Additive);
            }
    }
    void OnSceneLoaded(Scene scene,LoadSceneMode mode){
        isLoading = false;
        sceneInSpace loadedSceneInSpace;
        loadedSceneInSpace.scene = scene;
        loadedSceneInSpace.pos = loadingThisSceneSpacePosition;
        loadedSceneInSpace.sceneInGameIndex = currentSceneIndex;
        sceneSpace.Add(loadedSceneInSpace);//
        newRootTransforms = new GameObject[rootCount+2];
        newRootTransforms = scene.GetRootGameObjects();
        if(currentSceneIndex != lastLoadedSceneIndex){//Calculate new scene size.
            Vector4 minXminYmaxXmaxY = Vector4.zero;//x,y,z,w
            foreach(GameObject rooto in newRootTransforms){
                if(rooto.transform.position.x < minXminYmaxXmaxY.x){
                    minXminYmaxXmaxY.x = rooto.transform.position.x;
                }else if(rooto.transform.position.x > minXminYmaxXmaxY.z){
                    minXminYmaxXmaxY.z = rooto.transform.position.x;
                }
                if(rooto.transform.position.y < minXminYmaxXmaxY.y){
                    minXminYmaxXmaxY.y = rooto.transform.position.y;
                }else if(rooto.transform.position.y > minXminYmaxXmaxY.w){
                    minXminYmaxXmaxY.w = rooto.transform.position.y;
                }

                sceneSize.x = minXminYmaxXmaxY.z-minXminYmaxXmaxY.x;
                sceneSize.y = minXminYmaxXmaxY.w-minXminYmaxXmaxY.y;
                //sceneOffset
            }
        }//end calculate bounds.
        
        foreach(GameObject rooto in newRootTransforms){
            rooto.transform.position = rooto.transform.position + new Vector3(loadingThisSceneSpacePosition.x*(sceneSize.x+sceneBuffer.x),loadingThisSceneSpacePosition.y*(sceneSize.y+sceneBuffer.y),0);
        }
        lastLoadedSceneIndex = currentSceneIndex;
    }
    public void OneLessTreasure(){
        //Count how many treasures are in the ... scene? world?
        int treasureCount = GameObject.FindGameObjectsWithTag("Treasure").Length;
        if(treasureCount == 0){
            //if 0, time to move to next scene for loading scenes.
            currentSceneIndex++;
            if(currentSceneIndex == scenesInGame.Count){
                currentSceneIndex = 0;
                Debug.Log("Game Over! Last scene should move us to another end-game state so, like. This message doesnt exist.");
            }
        //if the last scene, do something else?
        }
    }
}
